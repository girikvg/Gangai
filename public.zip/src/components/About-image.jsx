
import Card from 'react-bootstrap/Card';
import base from '../image/base.jpg'


function Aboutimage() {
  return (
    <Card.Img variant="top" src={base} width="100%"height="400"/>
  );
}

export default Aboutimage;
