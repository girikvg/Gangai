
import Card from 'react-bootstrap/Card';

function Sec6content3() {
  return (
   
     
      <Card.Body>
        <Card.Title>Company</Card.Title>
        <Card.Text>
          <div className='sec6link'>
        <ul style={{listStyle:"none",textAlign:"left",marginLeft:"45px"}}>
                <li> home</li>
                <li>service</li>
                <li>water wash</li>
                <li>testimonial</li>
                <li>contact us</li>
            </ul>
            </div>

        </Card.Text>
      </Card.Body>
  );
}

export default Sec6content3;