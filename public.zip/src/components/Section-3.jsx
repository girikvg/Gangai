
import Video from "./Video-content";
import { Container } from "react-bootstrap";
function Section3bg() {
    return (
    
      <div className="section3bg">
        <Container>
        <Video/>
        </Container>
   

      </div>
    );
  }
  
  export default Section3bg;