function Ourheading() {
  return (
    <div className='text-center headingcss fontdesign marhead'>
      OUR LATEST PROJECT
      </div>
  );
}

export default Ourheading;