import Container from 'react-bootstrap/Container';



function Section7bg() {
  return (
    
     <div className='section7bg fontdesign'>
        <Container>
        <p className="mb-0">
          &copy; {new Date().getFullYear()} Gangai Borewell. All Rights Reserved.
        </p>
        </Container>
    
     </div>
    
  );
}

export default Section7bg;