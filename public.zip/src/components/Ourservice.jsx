import Container from 'react-bootstrap/Container';


function Ourservice() {
  return (
    <Container>

<div className='text-center headingcss fontdesign marhead'>
OUR SERVICES 
      </div>
    </Container>
  );
}

export default Ourservice;